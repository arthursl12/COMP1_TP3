#pragma once

#define IDENTIFIER 10

#define INT_CONSTANT 40
#define REAL_CONSTANT 50
#define CHAR_CONSTANT 60
#define BOOL_CONSTANT 70

#define RELOP 100
#define ADDOP 200
#define MULOP 300
#define NOT 400
#define ASSIGN 500



